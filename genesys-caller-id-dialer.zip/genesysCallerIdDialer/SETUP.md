# Genesys Caller ID Dialer – setup

Utility-bar LWC: agent enters a number, picks (or accepts a prefix-suggested) caller ID, and Apex calls
`POST /api/v2/conversations/calls` with `phoneNumber` and `agentIndicatedAddress`.

## 1. Genesys Cloud
1. Admin > Integrations > OAuth: create a client, grant type **Code Authorization**,
   redirect URI = the Salesforce External Credential callback URL (shown after step 2).
2. The endpoint requires **user context** (confirmed from the API docs by the requester), so
   Client Credentials will not work; keep Code Authorization with per-user sign-in.
   Scopes/permissions: use what the API Explorer lists for POST /api/v2/conversations/calls
   (not yet captured here). Also confirm refresh-token behavior so agents aren't re-prompted
   mid-shift.
3. Confirm the caller IDs in your list are approved for each agent under the new
   user-level caller ID feature.

## 2. Salesforce – auth (per-user, so the call is placed as the agent)
1. Setup > Named Credentials > External Credentials: new, protocol **OAuth 2.0**, flow
   **Browser Flow (Authorization Code)**, auth URL/token URL on your Genesys login host
   (region-specific), client ID/secret from step 1.
2. Create a Principal (Per User). Grant a Permission Set access to it.
3. Create Named Credential **genesys_caller_id** → URL = your region's API host
   (e.g. https://api.mypurecloud.com), using that External Credential.
4. Each agent authenticates once: Settings > External Credentials (user level).

## 3. Salesforce – caller ID list
Create Custom Metadata Type **Caller_ID_Option__mdt** with fields:
`Number__c` (Text, E.164), `Dial_Prefix__c` (Text, e.g. +44), `Sort_Order__c` (Number).
Add one record per localized DID. The dialer pre-selects the longest matching prefix
and the agent can override.

## 4. Deploy and place
Deploy `GenesysDialerController` and the `genesysCallerIdDialer` bundle.
Setup > App Manager > edit console app > Utility Items > add **Genesys Caller ID Dialer**.
Grant agents Apex class access to `GenesysDialerController`.

## Open items to verify before go-live
- `agentIndicatedAddress` format and validation (E.164? must match approved list? error codes).
- Whether an API-placed call in CX Cloud creates the VoiceCall record / screen pop.
- Required OAuth scopes and response shape (conversation id field).
- Native click-to-dial icons still bypass this popup.
