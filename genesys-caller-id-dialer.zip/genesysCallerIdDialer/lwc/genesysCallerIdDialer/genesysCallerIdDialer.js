import { LightningElement, api, wire } from 'lwc';
import getCallerIdOptions from '@salesforce/apex/GenesysDialerController.getCallerIdOptions';
import placeCall from '@salesforce/apex/GenesysDialerController.placeCall';

export default class GenesysCallerIdDialer extends LightningElement {
    phoneNumber = '';
    selectedCallerId = '';
    options = [];      // [{label, value, prefix}]
    status = '';
    error = '';
    isDialing = false;
    userPickedManually = false;

    @wire(getCallerIdOptions)
    wiredOptions({ data, error }) {
        if (data) {
            this.options = data.map((o) => ({ label: o.label, value: o.value, prefix: o.prefix }));
            if (!this.selectedCallerId && this.options.length) {
                this.selectedCallerId = this.options[0].value;
            }
        } else if (error) {
            this.error = this.reduceError(error);
        }
    }

    // Other components (or a Flow/Aura wrapper) can call this to pre-fill the number.
    @api
    dial(number) {
        this.phoneNumber = number;
        this.suggestCallerId();
    }

    get hasOptions() {
        return this.options.length > 0;
    }

    get dialDisabled() {
        return this.isDialing || !this.phoneNumber || !this.selectedCallerId;
    }

    handleNumberChange(event) {
        this.phoneNumber = event.target.value;
        this.suggestCallerId();
    }

    handleCallerIdChange(event) {
        this.selectedCallerId = event.detail.value;
        this.userPickedManually = true;
    }

    // Suggest a local DID by matching the dialed number's prefix (longest match wins).
    // Skipped once the agent has chosen manually.
    suggestCallerId() {
        if (this.userPickedManually) return;
        const digits = (this.phoneNumber || '').replace(/[^\d+]/g, '');
        let best = null;
        for (const o of this.options) {
            if (o.prefix && digits.startsWith(o.prefix) && (!best || o.prefix.length > best.prefix.length)) {
                best = o;
            }
        }
        if (best) this.selectedCallerId = best.value;
    }

    async handleDial() {
        this.error = '';
        this.status = '';
        this.isDialing = true;
        try {
            const conversationId = await placeCall({
                phoneNumber: this.phoneNumber,
                agentIndicatedAddress: this.selectedCallerId
            });
            this.status = `Call placed${conversationId ? ' (' + conversationId + ')' : ''}.`;
            this.userPickedManually = false;
        } catch (e) {
            this.error = this.reduceError(e);
        } finally {
            this.isDialing = false;
        }
    }

    reduceError(e) {
        return (e && e.body && e.body.message) || (e && e.message) || 'Unexpected error';
    }
}
