import { LightningElement, api, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';
import { CloseActionScreenEvent } from 'lightning/actions';
import getCallerIdOptions from '@salesforce/apex/GenesysDialerController.getCallerIdOptions';
import placeCall from '@salesforce/apex/GenesysDialerController.placeCall';
import getReauthUrl from '@salesforce/apex/GenesysDialerController.getReauthUrl';

// Quick Action for Contact and Lead (both have Phone and MobilePhone).
export default class GenesysDialAction extends LightningElement {
    _recordId;
    @api objectApiName;

    @api
    get recordId() {
        return this._recordId;
    }
    set recordId(value) {
        this._recordId = value;
    }

    callerOptions = [];
    record;
    selectedNumber = '';
    selectedCallerId = '';
    isDialing = false;
    needsAuth = false;
    error = '';

    get wireFields() {
        return this.objectApiName
            ? [`${this.objectApiName}.Phone`, `${this.objectApiName}.MobilePhone`]
            : undefined;
    }

    @wire(getRecord, { recordId: '$recordId', fields: '$wireFields' })
    wiredRecord({ data, error }) {
        if (data) {
            this.record = data;
            const nums = this.numberOptions;
            if (nums.length && !this.selectedNumber) {
                this.selectedNumber = nums[0].value;
                this.selectedCallerId = this.suggest(this.selectedNumber);
            }
        } else if (error) {
            this.error = this.reduceError(error);
        }
    }

    @wire(getCallerIdOptions)
    wiredOptions({ data, error }) {
        if (data) {
            this.callerOptions = data.map((o) => ({ label: o.label, value: o.value, prefix: o.prefix }));
            if (this.selectedNumber) {
                this.selectedCallerId = this.suggest(this.selectedNumber);
            } else if (this.callerOptions.length && !this.selectedCallerId) {
                this.selectedCallerId = this.callerOptions[0].value;
            }
        } else if (error) {
            this.error = this.reduceError(error);
        }
    }

    get numberOptions() {
        if (!this.record) return [];
        const out = [];
        const add = (field, label) => {
            const v = this.record.fields[field] && this.record.fields[field].value;
            if (v) out.push({ label: `${label}: ${v}`, value: v });
        };
        add('Phone', 'Phone');
        add('MobilePhone', 'Mobile');
        return out;
    }

    get hasNumbers() {
        return this.numberOptions.length > 0;
    }

    get dialDisabled() {
        return this.isDialing || !this.selectedNumber || !this.selectedCallerId;
    }

    // Suggest the option with the longest dial-prefix match for the number; else the first option.
    suggest(number) {
        const digits = (number || '').replace(/[^\d+]/g, '');
        let best = null;
        for (const o of this.callerOptions) {
            if (o.prefix && digits.startsWith(o.prefix) && (!best || o.prefix.length > best.prefix.length)) {
                best = o;
            }
        }
        if (best) return best.value;
        return this.callerOptions.length ? this.callerOptions[0].value : '';
    }

    handleNumberChange(event) {
        this.selectedNumber = event.detail.value;
        this.selectedCallerId = this.suggest(this.selectedNumber);
    }

    handleCallerIdChange(event) {
        this.selectedCallerId = event.detail.value;
    }

    handleCancel() {
        this.dispatchEvent(new CloseActionScreenEvent());
    }

    async handleDial() {
        this.isDialing = true;
        this.error = '';
        this.needsAuth = false;
        try {
            await placeCall({
                phoneNumber: this.selectedNumber,
                agentIndicatedAddress: this.selectedCallerId
            });
            this.dispatchEvent(new CloseActionScreenEvent());
        } catch (e) {
            const msg = this.reduceError(e);
            if (msg.includes('GENESYS_AUTH_REQUIRED')) {
                this.needsAuth = true;
                this.error = 'Your Genesys sign-in has expired. Sign in again, then place the call.';
            } else {
                this.error = msg;
            }
        } finally {
            this.isDialing = false;
        }
    }

    async handleReauth() {
        try {
            const url = await getReauthUrl({ returnUrl: window.location.href });
            window.open(url, '_blank');
        } catch (e) {
            this.error = this.reduceError(e);
        }
    }

    reduceError(e) {
        return (e && e.body && (e.body.message || (e.body[0] && e.body[0].message))) || (e && e.message) || 'Unexpected error';
    }
}
