import { LightningElement, api, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';
import getCallerIdOptions from '@salesforce/apex/GenesysDialerController.getCallerIdOptions';
import placeCall from '@salesforce/apex/GenesysDialerController.placeCall';

export default class GenesysRecordDialer extends LightningElement {
    @api recordId;
    @api objectApiName;
    // Comma-separated phone field API names. Set per page in App Builder.
    // Must exist on the object (Contact/Lead: Phone,MobilePhone; Account: Phone).
    @api phoneFields = 'Phone,MobilePhone';

    options = [];
    record;
    isModalOpen = false;
    targetNumber = '';
    targetLabel = '';
    selectedCallerId = '';
    isDialing = false;
    status = '';
    error = '';

    get fieldList() {
        return this.phoneFields
            .split(',')
            .map((f) => f.trim())
            .filter(Boolean);
    }

    get wireFields() {
        return this.fieldList.map((f) => `${this.objectApiName}.${f}`);
    }

    @wire(getRecord, { recordId: '$recordId', fields: '$wireFields' })
    wiredRecord({ data, error }) {
        if (data) {
            this.record = data;
            this.error = '';
        } else if (error) {
            this.error = this.reduceError(error);
        }
    }

    @wire(getCallerIdOptions)
    wiredOptions({ data, error }) {
        if (data) {
            this.options = data.map((o) => ({ label: o.label, value: o.value, prefix: o.prefix }));
        } else if (error) {
            this.error = this.reduceError(error);
        }
    }

    get numbers() {
        if (!this.record) return [];
        return this.fieldList
            .map((f) => ({
                key: f,
                label: this.prettyLabel(f),
                number: this.record.fields[f] && this.record.fields[f].value
            }))
            .filter((n) => n.number);
    }

    get hasNumbers() {
        return this.numbers.length > 0;
    }

    get dialDisabled() {
        return this.isDialing || !this.selectedCallerId;
    }

    prettyLabel(apiName) {
        return apiName.replace(/([a-z])([A-Z])/g, '$1 $2');
    }

    handleDialClick(event) {
        this.targetNumber = event.target.dataset.number;
        this.targetLabel = event.target.dataset.label;
        this.status = '';
        this.error = '';
        this.selectedCallerId = this.suggest(this.targetNumber);
        this.isModalOpen = true;
    }

    // Suggest a DID whose prefix is the longest match for the dialed number; else the first option.
    suggest(number) {
        const digits = (number || '').replace(/[^\d+]/g, '');
        let best = null;
        for (const o of this.options) {
            if (o.prefix && digits.startsWith(o.prefix) && (!best || o.prefix.length > best.prefix.length)) {
                best = o;
            }
        }
        if (best) return best.value;
        return this.options.length ? this.options[0].value : '';
    }

    handleCallerIdChange(event) {
        this.selectedCallerId = event.detail.value;
    }

    handleCancel() {
        this.isModalOpen = false;
    }

    async handleConfirm() {
        this.isDialing = true;
        this.error = '';
        try {
            await placeCall({
                phoneNumber: this.targetNumber,
                agentIndicatedAddress: this.selectedCallerId
            });
            this.status = `Calling ${this.targetNumber}...`;
            this.isModalOpen = false;
        } catch (e) {
            this.error = this.reduceError(e);
        } finally {
            this.isDialing = false;
        }
    }

    reduceError(e) {
        return (e && e.body && (e.body.message || (e.body[0] && e.body[0].message))) || (e && e.message) || 'Unexpected error';
    }
}
