public with sharing class GenesysDialerController {

    // Named Credential must point at your Genesys Cloud API host for your region.
    // Written for US East (https://api.mypurecloud.com); other regions change the Named
    // Credential URL, not this class. It must use a per-user
    // External Credential (OAuth 2.0 Authorization Code) so the call is placed AS the agent.
    private static final String NAMED_CREDENTIAL = 'callout:genesys_caller_id';

    public class CallerIdOption {
        @AuraEnabled public String label;
        @AuraEnabled public String value;   // E.164 DID sent as agentIndicatedAddress
        @AuraEnabled public String prefix;  // dial prefix used to suggest this DID, e.g. +44
    }

    // Options come from Custom Metadata Caller_ID_Option__mdt:
    //   Label (MasterLabel), Number__c (Text), Dial_Prefix__c (Text), Sort_Order__c (Number)
    // Swap this for a callout to your Genesys caller-ID list API if you want the
    // per-user approved list instead of a static list.
    @AuraEnabled(cacheable=true)
    public static List<CallerIdOption> getCallerIdOptions() {
        List<CallerIdOption> out = new List<CallerIdOption>();
        for (Caller_ID_Option__mdt m : [
            SELECT MasterLabel, Number__c, Dial_Prefix__c
            FROM Caller_ID_Option__mdt
            ORDER BY Sort_Order__c NULLS LAST, MasterLabel
        ]) {
            CallerIdOption o = new CallerIdOption();
            o.label = m.MasterLabel + ' (' + m.Number__c + ')';
            o.value = m.Number__c;
            o.prefix = m.Dial_Prefix__c;
            out.add(o);
        }
        return out;
    }

    @AuraEnabled
    public static String placeCall(String phoneNumber, String agentIndicatedAddress) {
        if (String.isBlank(phoneNumber) || String.isBlank(agentIndicatedAddress)) {
            throw new AuraHandledException('Phone number and caller ID are required.');
        }

        // agentIndicatedAddress is not in the published schema (per release info provided
        // by the requester). Confirm exact format/validation rules with Genesys.
        Map<String, Object> body = new Map<String, Object>{
            'phoneNumber' => phoneNumber,
            'agentIndicatedAddress' => agentIndicatedAddress
        };

        HttpRequest req = new HttpRequest();
        req.setEndpoint(NAMED_CREDENTIAL + '/api/v2/conversations/calls');
        req.setMethod('POST');
        req.setHeader('Content-Type', 'application/json');
        req.setTimeout(20000);
        req.setBody(JSON.serialize(body));

        HttpResponse res = new Http().send(req);
        if (res.getStatusCode() < 200 || res.getStatusCode() >= 300) {
            throw new AuraHandledException(
                'Genesys returned ' + res.getStatusCode() + ': ' + res.getBody()
            );
        }

        try {
            Map<String, Object> parsed = (Map<String, Object>) JSON.deserializeUntyped(res.getBody());
            return (String) parsed.get('id'); // conversation id (verify against actual response)
        } catch (Exception e) {
            return null;
        }
    }
}
