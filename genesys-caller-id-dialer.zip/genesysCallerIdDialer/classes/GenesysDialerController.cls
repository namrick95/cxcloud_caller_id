public with sharing class GenesysDialerController {

    // Named Credential must point at your Genesys Cloud API host for your region.
    // Written for US East (https://api.mypurecloud.com); other regions change the Named
    // Credential URL, not this class. It must use a per-user
    // External Credential (OAuth 2.0 Authorization Code) so the call is placed AS the agent.
    private static final String NAMED_CREDENTIAL = 'callout:GenesysAPI';
    // Developer name of the External Credential (per-user OAuth). Used to build the re-sign-in link.
    private static final String EXTERNAL_CREDENTIAL = 'callerId';
    // Message prefix the LWCs look for to show a "Sign in to Genesys" button.
    public static final String AUTH_REQUIRED = 'GENESYS_AUTH_REQUIRED';

    public class CallerIdOption {
        @AuraEnabled public String label;
        @AuraEnabled public String value;   // E.164 DID sent as agentIndicatedAddress
        @AuraEnabled public String prefix;  // dial prefix used to suggest this DID, e.g. +44
    }

    // Options come from Custom Metadata Caller_ID_Option__mdt:
    //   Label (MasterLabel), Number__c (Text), Dial_Prefix__c (Text), Sort_Order__c (Number)
    // Swap this for a callout to your Genesys caller-ID list API if you want the
    // per-user approved list instead of a static list.
    @AuraEnabled(cacheable=true)
    public static List<CallerIdOption> getCallerIdOptions() {
        List<CallerIdOption> out = new List<CallerIdOption>();
        for (Caller_ID_Option__mdt m : [
            SELECT MasterLabel, Number__c, Dial_Prefix__c
            FROM Caller_ID_Option__mdt
            ORDER BY Sort_Order__c NULLS LAST, MasterLabel
        ]) {
            CallerIdOption o = new CallerIdOption();
            o.label = m.MasterLabel + ' (' + m.Number__c + ')';
            o.value = m.Number__c;
            o.prefix = m.Dial_Prefix__c;
            out.add(o);
        }
        return out;
    }

    // Returns the URL that starts the Genesys sign-in (OAuth) flow for the current user.
    // The agent opens it, signs in, and Salesforce stores fresh tokens.
    @AuraEnabled
    public static String getReauthUrl(String returnUrl) {
        ConnectApi.OAuthCredentialAuthUrlInput input = new ConnectApi.OAuthCredentialAuthUrlInput();
        input.externalCredential = EXTERNAL_CREDENTIAL;
        input.principalType = ConnectApi.CredentialPrincipalType.PerUserPrincipal;
        // Send the agent back to the page they were on (passed in by the LWC).
        if (String.isNotBlank(returnUrl)) {
            input.returnUrl = returnUrl;
        }
        ConnectApi.OAuthCredentialAuthUrl result = ConnectApi.NamedCredentials.getOAuthCredentialAuthUrl(input);
        // Salesforce documents that special characters in this URL are encoded/escaped.
        return result.authenticationUrl.unescapeHtml4();
    }

    @AuraEnabled
    public static String placeCall(String phoneNumber, String agentIndicatedAddress) {
        if (String.isBlank(phoneNumber) || String.isBlank(agentIndicatedAddress)) {
            throw new AuraHandledException('Phone number and caller ID are required.');
        }

        // agentIndicatedAddress is not in the published schema (per release info provided
        // by the requester). Confirm exact format/validation rules with Genesys.
        Map<String, Object> body = new Map<String, Object>{
            'phoneNumber' => phoneNumber,
            'agentIndicatedAddress' => agentIndicatedAddress
        };

        HttpRequest req = new HttpRequest();
        req.setEndpoint(NAMED_CREDENTIAL + '/api/v2/conversations/calls');
        req.setMethod('POST');
        req.setHeader('Content-Type', 'application/json');
        req.setTimeout(20000);
        req.setBody(JSON.serialize(body));

        HttpResponse res;
        try {
            res = new Http().send(req);
        } catch (CalloutException e) {
            // Includes a missing or revoked per-user credential. The LWC offers a sign-in link.
            throw new AuraHandledException(AUTH_REQUIRED + ': ' + e.getMessage());
        }
        if (res.getStatusCode() == 401) {
            throw new AuraHandledException(AUTH_REQUIRED + ': Genesys returned 401');
        }
        if (res.getStatusCode() < 200 || res.getStatusCode() >= 300) {
            throw new AuraHandledException(
                'Genesys returned ' + res.getStatusCode() + ': ' + res.getBody()
            );
        }

        try {
            Map<String, Object> parsed = (Map<String, Object>) JSON.deserializeUntyped(res.getBody());
            return (String) parsed.get('id'); // conversation id (verify against actual response)
        } catch (Exception e) {
            return null;
        }
    }
}
